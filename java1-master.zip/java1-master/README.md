**Java Inicio**


**Descripcion**
La idea de este proyecto es que puedan ver lo mas basico del lenguaje Java, por 
ejemplo: los tipos de datos que se utilizan en una aplicacion, los cuales 
puedes encontrar en src/Clase1/TipoDeDatos.java

En "/src" podran encontrar todo lo relacionado a condicionales, 
ciclos repetitivos, array y otras cosas mas que forman parte de Java Inicio

**Importante**
Los ejercicios fueron realizados en NetBeans por ende si requieren utilizar otro
IDE para programar, entonces deberan descargar el repositorio y copiar el contenido
de la carpeta src en el src del proyecto que han creado o importar el contenido
de la misma a traves del  IDE.


Para este material se estara usando Java 8